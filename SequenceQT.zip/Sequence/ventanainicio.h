#ifndef VENTANAINICIO_H
#define VENTANAINICIO_H

#include <QDialog>

namespace Ui {
class ventanaInicio;
}

class ventanaInicio : public QDialog
{
    Q_OBJECT

public:
    explicit ventanaInicio(QWidget *parent = 0);
    ~ventanaInicio();

private slots:
    void on_playBotton_clicked();

    void on_closeButton_clicked();

private:
    Ui::ventanaInicio *ui;
};

#endif // VENTANAINICIO_H
