#include "selectionwindow.h"
#include "ui_selectionwindow.h"
#include "game.h"
#include <QMessageBox>
selectionWindow::selectionWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::selectionWindow)
{
    ui->setupUi(this);
}

selectionWindow::~selectionWindow()
{
    delete ui;
}



void selectionWindow::on_nextButton_clicked()
{
    QString players = ui->numeroJugadores->text();
    int players1 = players.toInt();
    if(players1 < 1 || players1 > 4 )
    {
        QMessageBox::information(this,"Error", "Tiene que ser una cantidad de jugadores entre 1 y 4.");
    }
    else if(ui->clasicButton->isChecked())
    {
        this->close();
         game c;
         c.setModal(true);
         c.exec();
    }
    else{
        QMessageBox::information(this,"Error", "Debe escoger una opcion.");
    }

}
