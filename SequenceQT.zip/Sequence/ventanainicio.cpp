#include "ventanainicio.h"
#include "ui_ventanainicio.h"
#include "game.h"
#include "selectionwindow.h"
ventanaInicio::ventanaInicio(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ventanaInicio)
{
    ui->setupUi(this);
    QPixmap bkgnd(":/imagenes/sequence.jpg");
        bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
        QPalette palette;
        palette.setBrush(QPalette::Background, bkgnd);
        this->setPalette(palette);
}

ventanaInicio::~ventanaInicio()
{
    delete ui;
}

void ventanaInicio::on_playBotton_clicked()
{
    this->close();
     selectionWindow c;
     c.setModal(true);
     c.exec();
}

void ventanaInicio::on_closeButton_clicked()
{
    this ->close();
}
