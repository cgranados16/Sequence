#ifndef SELECTIONWINDOW_H
#define SELECTIONWINDOW_H

#include <QDialog>

namespace Ui {
class selectionWindow;
}

class selectionWindow : public QDialog
{
    Q_OBJECT

public:
    explicit selectionWindow(QWidget *parent = 0);
    ~selectionWindow();

private slots:




    void on_nextButton_clicked();

private:
    Ui::selectionWindow *ui;
};

#endif // SELECTIONWINDOW_H
